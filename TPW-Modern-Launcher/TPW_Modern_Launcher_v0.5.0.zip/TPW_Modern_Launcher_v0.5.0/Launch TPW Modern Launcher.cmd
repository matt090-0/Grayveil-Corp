@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0TPWModernLauncher.ps1"
if errorlevel 1 (
  echo.
  echo TPW Modern Launcher returned an error.
  pause
)

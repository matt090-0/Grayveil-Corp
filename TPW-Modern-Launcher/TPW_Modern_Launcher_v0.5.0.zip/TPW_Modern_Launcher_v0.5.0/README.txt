Theme Park World Modern Launcher v0.5.0

WHY THIS VERSION EXISTS
-----------------------
v0.4 used DxWnd's local ddraw proxy mode. On the test PC the game started, but its
animation/FPS effectively froze. v0.5 removes that experimental route.

v0.5 follows the dedicated TPW-TPI-Fixes project's primary renderer method:
Theme Park World Direct3D 3 -> DDrawCompat -> modern Windows.

WHAT APPLY CLEAN FIX DOES
-------------------------
- backs up TP.exe, wrapper DLLs and SAM settings first
- removes DxWnd proxy files, dgVoodoo D3DImm, and the WinMM shim
- downloads the TPW-tested DDrawCompat DDraw.dll from TPW-TPI-Fixes
- writes the project's exact ddrawcompat.ini profile
- keeps TPW internally at 1024x768 and lets DDrawCompat scale to the desktop
- enables RENDER32 and TEXTURE32 in SAM settings
- applies the documented TP.exe 32-bit texture memory correction when recognised
- protects the tpwfnt directory with DONOTREMOVE.txt

FIRST TEST
----------
1. Run Launch TPW Modern Launcher.cmd as Administrator.
2. Select the Theme Park World folder if needed.
3. Click APPLY CLEAN FIX.
4. Restart Windows once.
5. Reopen the launcher as Administrator.
6. Click PLAY CLEAN FIX.

LONG UPTIME
-----------
Theme Park World has a known D3D timing problem on systems with long Windows uptime
(around 11 days and above). The launcher warns when this is relevant. Use a real
Windows Restart before playing instead of stacking another timing DLL into the game.

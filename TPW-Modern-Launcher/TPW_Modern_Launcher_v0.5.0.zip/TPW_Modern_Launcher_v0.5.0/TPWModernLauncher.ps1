﻿# Theme Park World Modern Launcher
# Version 0.5.0 - clean DDrawCompat path
# Windows PowerShell 5.1+

Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:AppName='Theme Park World Modern Launcher'
$script:AppVersion='0.5.0'
$script:GameDir=''
$script:Busy=$false
$script:LogLines=New-Object System.Collections.Generic.List[string]
$script:AppDataDir=Join-Path $env:LOCALAPPDATA 'TPWModernLauncher'
$script:SettingsPath=Join-Path $script:AppDataDir 'settings.json'
$script:DDrawUrl='https://raw.githubusercontent.com/HyperJeanJean/TPW-TPI-Fixes/main/Common/DDraw.dll'
$script:FixProjectUrl='https://github.com/HyperJeanJean/TPW-TPI-Fixes'
New-Item -ItemType Directory -Path $script:AppDataDir -Force | Out-Null

$C_BG=[System.Drawing.ColorTranslator]::FromHtml('#080B10')
$C_CARD=[System.Drawing.ColorTranslator]::FromHtml('#111821')
$C_CARD2=[System.Drawing.ColorTranslator]::FromHtml('#0C1219')
$C_TEXT=[System.Drawing.ColorTranslator]::FromHtml('#F2F5F8')
$C_MUTED=[System.Drawing.ColorTranslator]::FromHtml('#93A0AE')
$C_ACCENT=[System.Drawing.ColorTranslator]::FromHtml('#F4C95D')
$C_SUCCESS=[System.Drawing.ColorTranslator]::FromHtml('#55D6A0')
$C_WARN=[System.Drawing.ColorTranslator]::FromHtml('#FFAA5A')
$C_DANGER=[System.Drawing.ColorTranslator]::FromHtml('#FF6B6B')
$C_BORDER=[System.Drawing.ColorTranslator]::FromHtml('#263544')

function Write-UiLog {
    param([string]$Message,[string]$Level='INFO')
    $line="[{0}] [{1}] {2}" -f (Get-Date -Format 'HH:mm:ss'),$Level,$Message
    $script:LogLines.Add($line)
    if($script:LogLines.Count -gt 300){$script:LogLines.RemoveAt(0)}
    if($script:LogBox){
        $script:LogBox.Lines=$script:LogLines.ToArray()
        $script:LogBox.SelectionStart=$script:LogBox.TextLength
        $script:LogBox.ScrollToCaret()
    }
    [System.Windows.Forms.Application]::DoEvents()
}
function Show-Info([string]$Text,[string]$Title=$script:AppName){[System.Windows.Forms.MessageBox]::Show($Text,$Title,'OK','Information')|Out-Null}
function Show-Warn([string]$Text,[string]$Title=$script:AppName){[System.Windows.Forms.MessageBox]::Show($Text,$Title,'OK','Warning')|Out-Null}
function Show-ErrorBox([string]$Text,[string]$Title=$script:AppName){[System.Windows.Forms.MessageBox]::Show($Text,$Title,'OK','Error')|Out-Null}
function Confirm-Action([string]$Text,[string]$Title=$script:AppName){return ([System.Windows.Forms.MessageBox]::Show($Text,$Title,'YesNo','Question') -eq 'Yes')}

function Load-Settings { try{if(Test-Path $script:SettingsPath){return (Get-Content $script:SettingsPath -Raw|ConvertFrom-Json)}}catch{};return $null }
function Save-Settings { try{[ordered]@{gameDir=$script:GameDir;version=$script:AppVersion}|ConvertTo-Json|Set-Content $script:SettingsPath -Encoding UTF8}catch{} }
function Test-GameFolder([string]$Path){return (-not[string]::IsNullOrWhiteSpace($Path)) -and (Test-Path (Join-Path $Path 'TP.exe'))}
function Find-GameFolder {
    $c=New-Object Collections.Generic.List[string]
    $s=Load-Settings;if($s -and $s.gameDir){$c.Add([string]$s.gameDir)}
    $c.Add("${env:ProgramFiles(x86)}\Bullfrog\Theme Park World")
    $c.Add('C:\Games\Theme Park World')
    foreach($p in ($c|Select-Object -Unique)){if($p -and (Test-GameFolder $p)){return $p}}
    return ''
}
function Test-WriteAccess([string]$Path){
    if(-not(Test-Path $Path)){return $false}
    $p=Join-Path $Path ('.tpwml_'+[guid]::NewGuid().ToString('N')+'.tmp')
    try{[IO.File]::WriteAllText($p,'x');Remove-Item $p -Force;return $true}catch{Remove-Item $p -Force -ErrorAction SilentlyContinue;return $false}
}
function Get-OsUptime {
    try{$os=Get-CimInstance Win32_OperatingSystem;return ((Get-Date)-$os.LastBootUpTime)}
    catch{return [TimeSpan]::FromMilliseconds([Environment]::TickCount64)}
}
function Restart-AsAdministrator {
    try{
        $args="-NoProfile -ExecutionPolicy Bypass -STA -File `"$PSCommandPath`""
        Start-Process powershell.exe -Verb RunAs -ArgumentList $args
        $script:Form.Close()
    }catch{Show-ErrorBox $_.Exception.Message}
}

function Backup-CurrentSetup {
    if(-not(Test-GameFolder $script:GameDir)){throw 'Choose the Theme Park World folder first.'}
    $root=Join-Path $script:GameDir 'TPWModernLauncher_Backups'
    $dest=Join-Path $root (Get-Date -Format 'yyyy-MM-dd_HHmmss')
    New-Item -ItemType Directory -Path $dest -Force|Out-Null
    $names=@(
        'TP.exe','DDraw.dll','D3DImm.dll','winmm.dll','dgVoodoo.conf','DDrawCompat.ini',
        'dxwnd.dll','dxwnd.dxw','QMixer.dll','usp11.dll',
        'DDraw.dll.tpwlauncher-disabled','D3DImm.dll.tpwlauncher-disabled',
        'winmm.dll.tpwlauncher-disabled','dgVoodoo.conf.tpwlauncher-disabled',
        'DDrawCompat.ini.tpwlauncher-disabled'
    )
    foreach($n in $names){$p=Join-Path $script:GameDir $n;if(Test-Path $p){Copy-Item $p (Join-Path $dest $n) -Force}}
    $data=Join-Path $script:GameDir 'data'
    if(Test-Path $data){
        Get-ChildItem $data -File -Recurse -ErrorAction SilentlyContinue |
          Where-Object {$_.Extension -eq '.sam' -or $_.Name -eq 'DONOTREMOVE.txt'} | ForEach-Object{
            $rel=$_.FullName.Substring($script:GameDir.Length).TrimStart('\')
            $out=Join-Path $dest $rel
            New-Item -ItemType Directory -Path (Split-Path $out -Parent) -Force|Out-Null
            Copy-Item $_.FullName $out -Force
        }
    }
    "TPW Modern Launcher backup`r`nCreated: $(Get-Date)`r`nVersion: $script:AppVersion" |
      Set-Content (Join-Path $dest 'backup-info.txt') -Encoding UTF8
    Write-UiLog "Backup created: $dest" 'OK'
    return $dest
}
function Restore-LatestBackup {
    $root=Join-Path $script:GameDir 'TPWModernLauncher_Backups'
    if(-not(Test-Path $root)){throw 'No launcher backups were found.'}
    $latest=Get-ChildItem $root -Directory|Sort-Object Name -Descending|Select-Object -First 1
    if(-not $latest){throw 'No launcher backups were found.'}
    if(-not(Confirm-Action "Restore newest backup?`r`n`r`n$($latest.FullName)")){return}
    foreach($n in @('DDraw.dll','D3DImm.dll','winmm.dll','dgVoodoo.conf','DDrawCompat.ini','dxwnd.dll','dxwnd.dxw')){
        $saved=Join-Path $latest.FullName $n
        $current=Join-Path $script:GameDir $n
        if(-not(Test-Path $saved) -and (Test-Path $current)){Remove-Item $current -Force -ErrorAction SilentlyContinue}
    }
    Get-ChildItem $latest.FullName -File -Recurse|Where-Object{$_.Name -ne 'backup-info.txt'}|ForEach-Object{
        $rel=$_.FullName.Substring($latest.FullName.Length).TrimStart('\')
        $out=Join-Path $script:GameDir $rel
        New-Item -ItemType Directory -Path (Split-Path $out -Parent) -Force|Out-Null
        Copy-Item $_.FullName $out -Force
    }
    Write-UiLog "Restored backup: $($latest.Name)" 'OK'
    Refresh-Status
}

function Find-PatternOffsets([byte[]]$Bytes,[byte[]]$Pattern){
    $r=New-Object Collections.Generic.List[int]
    for($i=0;$i -le $Bytes.Length-$Pattern.Length;$i++){
        $ok=$true
        for($j=0;$j -lt $Pattern.Length;$j++){if($Bytes[$i+$j] -ne $Pattern[$j]){$ok=$false;break}}
        if($ok){$r.Add($i)}
    }
    return $r.ToArray()
}
function Apply-TpwTextureMemoryPatch {
    $exe=Join-Path $script:GameDir 'TP.exe'
    $old=[byte[]](0x24,0x10,0xC1,0xE0,0x10)
    $new=[byte[]](0x24,0x10,0xC1,0xE0,0x13)
    $bytes=[IO.File]::ReadAllBytes($exe)
    if(@(Find-PatternOffsets $bytes $new).Count -gt 0){Write-UiLog 'TP.exe texture-memory patch already present.' 'OK';return}
    $hits=@(Find-PatternOffsets $bytes $old)
    if($hits.Count -eq 0){Write-UiLog 'TP.exe texture-memory signature not found; executable left untouched.' 'WARN';return}
    foreach($o in $hits){$bytes[$o+4]=0x13}
    [IO.File]::WriteAllBytes($exe,$bytes)
    Write-UiLog "Applied TP.exe texture-memory fix ($($hits.Count) signature(s))." 'OK'
}
function Set-GameFiles {
    $data=Join-Path $script:GameDir 'data'
    if(-not(Test-Path $data)){throw 'Game data folder not found.'}

    $files=@(Get-ChildItem $data -Filter '*.sam' -File -Recurse -ErrorAction SilentlyContinue)
    $changed=0
    foreach($f in $files){
        try{
            $t=Get-Content $f.FullName -Raw;$b=$t
            $t=[regex]::Replace($t,'(?im)^(\s*GraphicalOptions\.RENDER32\s+)\S+\s*$','${1}1')
            $t=[regex]::Replace($t,'(?im)^(\s*GraphicalOptions\.TEXTURE32\s+)\S+\s*$','${1}1')
            if($t -ne $b){Set-Content $f.FullName $t -Encoding Default;$changed++}
        }catch{}
    }
    Write-UiLog "Hardware renderer + 32-bit textures checked ($changed file changes)." 'OK'

    $res=Join-Path $data 'Resolution.sam'
    if(Test-Path $res){
        $t=Get-Content $res -Raw
        if($t -match '(?im)^\s*Res\.RESOLUTION\s+\d+'){
            $t=[regex]::Replace($t,'(?im)^(\s*Res\.RESOLUTION\s+)\d+\s*$','${1}4',1)
        }else{
            $t+="`r`nRes.RESOLUTION`t4`r`n"
        }
        Set-Content $res $t -Encoding Default
        Write-UiLog 'Internal game resolution set to 1024x768.' 'OK'
    }

    $fnt=Join-Path $data 'tpwfnt'
    if(-not(Test-Path $fnt)){New-Item -ItemType Directory -Path $fnt -Force|Out-Null}
    $sentinel=Join-Path $fnt 'DONOTREMOVE.txt'
    if(-not(Test-Path $sentinel)){Set-Content $sentinel 'TPW font folder sentinel' -Encoding ASCII}
    try{(Get-Item $sentinel).IsReadOnly=$true}catch{}
    Write-UiLog 'Font-folder sentinel checked.' 'OK'
}
function Remove-ConflictingHooks {
    try{@(Get-Process -Name 'DxWnd' -ErrorAction SilentlyContinue)|Stop-Process -Force -ErrorAction SilentlyContinue}catch{}
    foreach($n in @('dxwnd.dll','dxwnd.dxw','D3DImm.dll','winmm.dll','dgVoodoo.conf')){
        $p=Join-Path $script:GameDir $n
        if(Test-Path $p){Remove-Item $p -Force -ErrorAction SilentlyContinue;Write-UiLog "Removed conflicting hook: $n" 'OK'}
    }
    # Old launchers may have left inactive copies behind. They are harmless and kept for rollback.
}
function Test-PeDll([string]$Path,[int64]$MinSize=1000000){
    try{
        if(-not(Test-Path $Path)){return $false}
        if((Get-Item $Path).Length -lt $MinSize){return $false}
        $fs=[IO.File]::OpenRead($Path)
        try{$b1=$fs.ReadByte();$b2=$fs.ReadByte()}finally{$fs.Dispose()}
        return ($b1 -eq 0x4D -and $b2 -eq 0x5A)
    }catch{return $false}
}
function Download-DDrawCompat {
    $temp=Join-Path ([IO.Path]::GetTempPath()) ('TPWDDC_'+[guid]::NewGuid().ToString('N')+'.dll')
    try{
        [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
        Write-UiLog 'Downloading the TPW-tested DDrawCompat build from the TPW-TPI-Fixes project...'
        $curl=Get-Command curl.exe -ErrorAction SilentlyContinue
        if($curl){
            try{& $curl.Source -L --fail --silent --show-error --retry 2 -A 'Mozilla/5.0' -o $temp $script:DDrawUrl}catch{}
        }
        if(-not(Test-PeDll $temp 2000000)){
            Remove-Item $temp -Force -ErrorAction SilentlyContinue
            Invoke-WebRequest -Uri $script:DDrawUrl -OutFile $temp -UseBasicParsing -Headers @{'User-Agent'='Mozilla/5.0'}
        }
        if(-not(Test-PeDll $temp 2000000)){throw 'The downloaded DDraw.dll did not pass validation.'}
        Copy-Item $temp (Join-Path $script:GameDir 'DDraw.dll') -Force
        Write-UiLog ("DDrawCompat installed ({0:N1} MB)." -f ((Get-Item $temp).Length/1MB)) 'OK'
    }finally{Remove-Item $temp -Force -ErrorAction SilentlyContinue}
}
function Write-DDrawCompatConfig {
    $cfg=@'
DisplayResolution = desktop
FullScreenMode = borderless
SupportedResolutions = 512x384,640x480,720x540,800x600,960x720,1024x768,1280x1024,1440x1080,1600x1200,1920x1440,2048x1536,2880x2160
TextureFilter = af16x
LogLevel = none
'@
    Set-Content (Join-Path $script:GameDir 'ddrawcompat.ini') $cfg -Encoding ASCII
    Write-UiLog 'Installed the exact TPW-TPI-Fixes DDrawCompat profile.' 'OK'
}
function Test-CleanFix {
    if(-not(Test-GameFolder $script:GameDir)){return $false}
    return (Test-PeDll (Join-Path $script:GameDir 'DDraw.dll') 2000000) -and
           (Test-Path (Join-Path $script:GameDir 'ddrawcompat.ini')) -and
           (-not(Test-Path (Join-Path $script:GameDir 'dxwnd.dll'))) -and
           (-not(Test-Path (Join-Path $script:GameDir 'D3DImm.dll'))) -and
           (-not(Test-Path (Join-Path $script:GameDir 'winmm.dll')))
}
function Apply-CleanFix {
    if($script:Busy){return}
    if(-not(Test-GameFolder $script:GameDir)){Show-Warn 'Choose the Theme Park World folder first.';return}
    if(-not(Test-WriteAccess $script:GameDir)){Show-Warn 'Run the launcher as Administrator first.';return}
    if(-not(Confirm-Action ("Replace the experimental DxWnd/dgVoodoo setup with the clean TPW fix?`r`n`r`n"+
        "This makes a backup first, removes conflicting hooks, installs the TPW-tested DDrawCompat build, "+
        "sets the game to 1024x768 internally, enables the hardware renderer, and applies the texture-memory fix."))){return}
    $script:Busy=$true
    try{
        $script:FixButton.Enabled=$false;$script:PlayButton.Enabled=$false
        Backup-CurrentSetup|Out-Null
        Remove-ConflictingHooks
        Download-DDrawCompat
        Write-DDrawCompatConfig
        Set-GameFiles
        Apply-TpwTextureMemoryPatch
        Write-UiLog 'Clean TPW renderer path is ready.' 'OK'
        Refresh-Status
        Show-Info ("Clean fix installed.`r`n`r`n"+
                   "Renderer path: TPW Direct3D 3 -> DDrawCompat -> Windows`r`n"+
                   "Internal resolution: 1024x768`r`n"+
                   "Output: desktop borderless`r`n"+
                   "Extra hooks: none`r`n`r`n"+
                   "For the cleanest first test, restart Windows once, then reopen this launcher and click PLAY CLEAN FIX.")
    }catch{
        Write-UiLog $_.Exception.Message 'ERROR'
        Show-ErrorBox ("Clean fix failed:`r`n`r`n"+$_.Exception.Message)
    }finally{$script:Busy=$false;$script:FixButton.Enabled=$true;Refresh-Status}
}
function Play-CleanFix {
    if(-not(Test-GameFolder $script:GameDir)){Show-Warn 'TP.exe was not found.';return}
    if(-not(Test-CleanFix)){Show-Warn 'The clean DDrawCompat fix is not installed yet. Click APPLY CLEAN FIX first.';return}
    $uptime=Get-OsUptime
    if($uptime.TotalDays -ge 10.5){
        if(-not(Confirm-Action ("Windows has been running for {0:N1} days.`r`n`r`nTheme Park World has a known D3D timing problem around long Windows uptimes. A real Windows Restart is recommended before playing.`r`n`r`nLaunch anyway?" -f $uptime.TotalDays) 'TPW timing warning')){return}
    }
    try{
        try{@(Get-Process -Name 'DxWnd' -ErrorAction SilentlyContinue)|Stop-Process -Force -ErrorAction SilentlyContinue}catch{}
        $tp=Join-Path $script:GameDir 'TP.exe'
        Write-UiLog ("Launching clean DDrawCompat path. Windows uptime: {0:N1} days." -f $uptime.TotalDays)
        Start-Process -FilePath $tp -WorkingDirectory $script:GameDir
    }catch{Write-UiLog $_.Exception.Message 'ERROR';Show-ErrorBox $_.Exception.Message}
}
function Copy-Report {
    $up=Get-OsUptime
    $layers=''
    try{
        $key='HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers'
        $tp=Join-Path $script:GameDir 'TP.exe'
        $v=(Get-ItemProperty -Path $key -Name $tp -ErrorAction SilentlyContinue).$tp
        if($v){$layers=[string]$v}
    }catch{}
    $lines=@(
        "$script:AppName v$script:AppVersion",
        "Game folder: $script:GameDir",
        "Game found: $(Test-GameFolder $script:GameDir)",
        "Clean fix installed: $(Test-CleanFix)",
        ("Windows uptime days: {0:N2}" -f $up.TotalDays),
        "Compatibility flags: $layers",
        "DDraw.dll: $(Test-Path (Join-Path $script:GameDir 'DDraw.dll'))",
        "DDrawCompat.ini: $(Test-Path (Join-Path $script:GameDir 'ddrawcompat.ini'))",
        "DxWnd proxy dll: $(Test-Path (Join-Path $script:GameDir 'dxwnd.dll'))",
        "dgVoodoo D3DImm: $(Test-Path (Join-Path $script:GameDir 'D3DImm.dll'))",
        "WinMM shim: $(Test-Path (Join-Path $script:GameDir 'winmm.dll'))",
        '',
        'Activity:',
        ($script:LogLines -join "`r`n")
    )
    $txt=$lines -join "`r`n"
    [System.Windows.Forms.Clipboard]::SetText($txt)
    Write-UiLog 'Report copied to clipboard.' 'OK'
    Show-Info 'Report copied to clipboard.'
}
function Open-FixProject { try{Start-Process $script:FixProjectUrl}catch{} }

function New-Label([string]$Text,[float]$Size,[System.Drawing.Point]$Location,[System.Drawing.Size]$SizeBox,[System.Drawing.Color]$Color=$C_TEXT,[string]$Style='Regular'){
    $l=New-Object System.Windows.Forms.Label;$l.Text=$Text;$l.Location=$Location;$l.Size=$SizeBox;$l.ForeColor=$Color;$l.BackColor=[System.Drawing.Color]::Transparent
    $l.Font=New-Object System.Drawing.Font('Segoe UI',$Size,[System.Drawing.FontStyle]::$Style);return $l
}
function New-Button([string]$Text,[System.Drawing.Point]$Location,[System.Drawing.Size]$Size,[System.Drawing.Color]$Back=$C_CARD2,[System.Drawing.Color]$Fore=$C_TEXT){
    $b=New-Object System.Windows.Forms.Button;$b.Text=$Text;$b.Location=$Location;$b.Size=$Size;$b.BackColor=$Back;$b.ForeColor=$Fore
    $b.FlatStyle='Flat';$b.FlatAppearance.BorderColor=$C_BORDER;$b.FlatAppearance.BorderSize=1;$b.Font=New-Object System.Drawing.Font('Segoe UI Semibold',9);return $b
}
function New-Panel([System.Drawing.Point]$Location,[System.Drawing.Size]$Size){
    $p=New-Object System.Windows.Forms.Panel;$p.Location=$Location;$p.Size=$Size;$p.BackColor=$C_CARD
    $p.BorderStyle='FixedSingle';return $p
}
function Set-Status($Label,[string]$Text,[string]$State='normal'){
    $Label.Text=$Text
    switch($State){'ok'{$Label.ForeColor=$C_SUCCESS};'warn'{$Label.ForeColor=$C_WARN};'bad'{$Label.ForeColor=$C_DANGER};default{$Label.ForeColor=$C_TEXT}}
}
function Refresh-Status {
    $ok=Test-GameFolder $script:GameDir
    if($ok){Set-Status $script:GameStatus 'GAME FOUND [OK]' 'ok'}else{Set-Status $script:GameStatus 'GAME NOT FOUND' 'bad'}
    if($ok -and (Test-CleanFix)){Set-Status $script:RendererStatus 'Renderer: TPW-tested DDrawCompat [OK]' 'ok'}elseif($ok){Set-Status $script:RendererStatus 'Renderer: clean fix not installed' 'warn'}else{Set-Status $script:RendererStatus 'Renderer: -'}
    $up=Get-OsUptime
    if($up.TotalDays -lt 10.5){Set-Status $script:TimingStatus ("Timing: Windows uptime {0:N1} days [OK]" -f $up.TotalDays) 'ok'}
    else{Set-Status $script:TimingStatus ("Timing: uptime {0:N1} days - restart recommended" -f $up.TotalDays) 'warn'}
    if($ok){$script:PlayButton.Enabled=(Test-CleanFix)}else{$script:PlayButton.Enabled=$false}
    if($script:FolderBox){$script:FolderBox.Text=$script:GameDir}
}

$form=New-Object System.Windows.Forms.Form;$script:Form=$form
$form.Text="$script:AppName  v$script:AppVersion";$form.Size=New-Object System.Drawing.Size(980,690)
$form.MinimumSize=$form.Size;$form.MaximumSize=$form.Size;$form.StartPosition='CenterScreen'
$form.BackColor=$C_BG;$form.ForeColor=$C_TEXT;$form.FormBorderStyle='FixedSingle';$form.MaximizeBox=$false

$form.Controls.Add((New-Label 'THEME PARK WORLD' 9 (New-Object System.Drawing.Point(30,24)) (New-Object System.Drawing.Size(220,20)) $C_ACCENT 'Bold'))
$form.Controls.Add((New-Label 'Modern Launcher' 26 (New-Object System.Drawing.Point(27,43)) (New-Object System.Drawing.Size(430,48)) $C_TEXT 'Bold'))
$form.Controls.Add((New-Label 'Clean 1999 renderer repair. No dgVoodoo. No DxWnd proxy. No timing shim.' 9.7 (New-Object System.Drawing.Point(30,91)) (New-Object System.Drawing.Size(880,25)) $C_MUTED))

$folder=New-Panel (New-Object System.Drawing.Point(30,126)) (New-Object System.Drawing.Size(900,86))

$folder.Controls.Add((New-Label 'GAME FOLDER' 9 (New-Object System.Drawing.Point(16,11)) (New-Object System.Drawing.Size(140,20)) $C_TEXT 'Bold'))
$box=New-Object System.Windows.Forms.TextBox;$script:FolderBox=$box;$box.Location=New-Object System.Drawing.Point(17,39);$box.Size=New-Object System.Drawing.Size(720,27);$box.BackColor=$C_CARD2;$box.ForeColor=$C_TEXT;$box.BorderStyle='FixedSingle';$folder.Controls.Add($box)
$browse=New-Button 'Browse...' (New-Object System.Drawing.Point(750,35)) (New-Object System.Drawing.Size(125,34))
$browse.Add_Click({
    $dlg=New-Object System.Windows.Forms.FolderBrowserDialog;$dlg.Description='Choose the Theme Park World folder containing TP.exe'
    if($dlg.ShowDialog() -eq 'OK'){$script:GameDir=$dlg.SelectedPath;Save-Settings;Refresh-Status}
});$folder.Controls.Add($browse);$form.Controls.Add($folder)

$status=New-Panel (New-Object System.Drawing.Point(30,228)) (New-Object System.Drawing.Size(390,285))
$status.Controls.Add((New-Label 'SYSTEM CHECK' 10 (New-Object System.Drawing.Point(18,16)) (New-Object System.Drawing.Size(180,24)) $C_TEXT 'Bold'))
$gs=New-Label '' 13 (New-Object System.Drawing.Point(18,58)) (New-Object System.Drawing.Size(350,34));$script:GameStatus=$gs;$status.Controls.Add($gs)
$rs=New-Label '' 10 (New-Object System.Drawing.Point(18,112)) (New-Object System.Drawing.Size(350,50));$script:RendererStatus=$rs;$status.Controls.Add($rs)
$ts=New-Label '' 10 (New-Object System.Drawing.Point(18,174)) (New-Object System.Drawing.Size(350,52));$script:TimingStatus=$ts;$status.Controls.Add($ts)
$admin=New-Button 'Run as Administrator' (New-Object System.Drawing.Point(18,232)) (New-Object System.Drawing.Size(170,34));$admin.Add_Click({Restart-AsAdministrator});$status.Controls.Add($admin)
$project=New-Button 'Fix Project' (New-Object System.Drawing.Point(199,232)) (New-Object System.Drawing.Size(170,34));$project.Add_Click({Open-FixProject});$status.Controls.Add($project)
$form.Controls.Add($status)

$actions=New-Panel (New-Object System.Drawing.Point(440,228)) (New-Object System.Drawing.Size(490,285))
$actions.Controls.Add((New-Label 'CLEAN RENDERER PATH' 11 (New-Object System.Drawing.Point(18,16)) (New-Object System.Drawing.Size(250,26)) $C_ACCENT 'Bold'))
$actions.Controls.Add((New-Label 'This removes the experimental proxy stack and installs the exact DDrawCompat setup used by the dedicated TPW fixes project.' 9 (New-Object System.Drawing.Point(18,49)) (New-Object System.Drawing.Size(450,48)) $C_MUTED))
$fix=New-Button 'APPLY CLEAN FIX' (New-Object System.Drawing.Point(18,112)) (New-Object System.Drawing.Size(210,50)) $C_ACCENT $C_BG;$script:FixButton=$fix;$fix.Font=New-Object System.Drawing.Font('Segoe UI Semibold',10.5);$fix.Add_Click({Apply-CleanFix});$actions.Controls.Add($fix)
$play=New-Button 'PLAY CLEAN FIX' (New-Object System.Drawing.Point(246,112)) (New-Object System.Drawing.Size(220,50)) $C_SUCCESS $C_BG;$script:PlayButton=$play;$play.Font=New-Object System.Drawing.Font('Segoe UI Semibold',10.5);$play.Add_Click({Play-CleanFix});$actions.Controls.Add($play)
$restore=New-Button 'Restore Backup' (New-Object System.Drawing.Point(18,181)) (New-Object System.Drawing.Size(210,38));$restore.Add_Click({try{Restore-LatestBackup}catch{Show-ErrorBox $_.Exception.Message}});$actions.Controls.Add($restore)
$report=New-Button 'Copy Report' (New-Object System.Drawing.Point(246,181)) (New-Object System.Drawing.Size(220,38));$report.Add_Click({Copy-Report});$actions.Controls.Add($report)
$actions.Controls.Add((New-Label 'After applying the fix, one real Windows Restart is recommended before the first test.' 8.5 (New-Object System.Drawing.Point(18,234)) (New-Object System.Drawing.Size(445,34)) $C_WARN))
$form.Controls.Add($actions)

$activity=New-Panel (New-Object System.Drawing.Point(30,529)) (New-Object System.Drawing.Size(900,104))
$activity.Controls.Add((New-Label 'ACTIVITY' 9 (New-Object System.Drawing.Point(16,8)) (New-Object System.Drawing.Size(100,18)) $C_TEXT 'Bold'))
$log=New-Object System.Windows.Forms.TextBox;$script:LogBox=$log;$log.Location=New-Object System.Drawing.Point(16,29);$log.Size=New-Object System.Drawing.Size(866,58);$log.Multiline=$true;$log.ReadOnly=$true;$log.ScrollBars='Vertical';$log.BackColor=$C_CARD2;$log.ForeColor=$C_MUTED;$log.BorderStyle='FixedSingle';$log.Font=New-Object System.Drawing.Font('Consolas',8.5);$activity.Controls.Add($log);$form.Controls.Add($activity)

$form.Controls.Add((New-Label 'No game files are bundled. DDrawCompat is downloaded from the public TPW-TPI-Fixes repository.' 8 (New-Object System.Drawing.Point(31,638)) (New-Object System.Drawing.Size(790,18)) $C_MUTED))
$form.Controls.Add((New-Label "v$script:AppVersion" 8 (New-Object System.Drawing.Point(890,638)) (New-Object System.Drawing.Size(55,18)) $C_MUTED))

$script:GameDir=Find-GameFolder
Write-UiLog 'v0.5.0: clean DDrawCompat route; experimental DxWnd proxy removed from the primary path.' 'INFO'
Refresh-Status
[void]$form.ShowDialog()
